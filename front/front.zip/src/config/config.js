export default {
	baseUrl: 'http://localhost:8080/car/',
	name: '/car',
	indexNav: [
		{
			name: '新能源汽车',
			url: '/index/xinnengyuanqiche',
		},
		{
			name: '售后服务',
			url: '/index/shouhoufuwu',
		},
		{
			name: '故障排查',
			url: '/index/guzhangpaicha',
		},
	],
	cateList: [
		{
			name: '售后服务',
			refTable: 'fuwufenlei',
			refColumn: 'fuwufenlei',
		},
	]
}
